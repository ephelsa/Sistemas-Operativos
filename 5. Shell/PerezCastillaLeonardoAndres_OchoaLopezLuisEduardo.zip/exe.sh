clear

echo "gcc"
gcc -o promt.out *.c -Wall

echo ""

./promt.out