#ifndef COMMANDS_H
#define COMMANDS_H

void udea_pwd(); // Current folder
void udea_cd(char *); // Change folder
void udea_echo(int, char **);    // Message
void udea_clr(); // Clear promt
void udea_time();    // Show current time
void udea_exit();    // Close the promt


#endif /* commands_h */
